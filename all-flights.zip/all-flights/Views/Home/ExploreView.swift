//
//  ExploreView.swift
//  all-flights
//
//  Created by Akash Kottill on 13/05/25.
//

import SwiftUI

struct ExploreView: View {
    var body: some View {
        Text("ExploreView")
    }
}
