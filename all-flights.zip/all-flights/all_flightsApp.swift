//
//  all_flightsApp.swift
//  all-flights
//
//  Created by Akash Kottill on 13/05/25.
//

import SwiftUI

@main
struct all_flightsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
