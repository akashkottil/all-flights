//
//  ContentView.swift
//  all-flights
//
//  Created by Akash Kottill on 13/05/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        RootTabView()
    }
}

#Preview {
    ContentView()
}
